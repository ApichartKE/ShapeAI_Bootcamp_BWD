import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This is the 7 day bootcamp taken up by Shaurya Sinha Sir. The first 3
        day we covered the basics of HTML and for the rest of the days are we
        learned React. We learned everything from scratch including Javascript
        and React.js, HTML.
      </p>
    </div>
  );
}

export default Note;